ConfigLicense = {
    user = "",
    license = ""
}

config = {
    ['serverName'] = "Servidor Roleplay",
    ['serverIcon'] = "https://i.imgur.com/S4Dc2F2.png",

    ['commands'] = {
        ['prefix'] = "_ac",
        ['commandsList'] = {
            ['unpunish'] = {
                -- Comando: _ac unpunish <serial>
                datas = {}, -- ElementData que poderá executar o comando
                groups = {"Console", "Admin"} -- ACl que poderá executar o comando
            },
            ['punish'] = {
                -- Comando: _ac punish <serial || identificator> <reason>
                datas = {}, -- ElementData que poderá executar o comando
                groups = {"Console", "Admin", "Admin +"} -- ACl que poderá executar o comando
            },
            ['screenview'] = {
                -- Comando: _ac screenview
                datas = {}, -- ElementData que poderá executar o comando
                groups = {"Console"} -- ACl que poderá executar o comando
            },
            ['screenshot'] = {
                -- Comando: _ac screenshot
                datas = {}, -- ElementData que poderá executar o comando
                groups = {"Console"} -- ACL que poderá executar o comando
            }
        }
    },
    ['modules'] = {
        ["Stopper"] = {
            start = true,
            resource = "nxac_auxiliar",
            cheatType = "challenge",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Spoofer"] = {
            start = true,
            cheatType = "spoofer",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Vpn"] = {
            start = true,
            cheatType = "vpn",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Screenshot"] = {
            start = true,
            cheatType = "noscreen",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Change Data"] = {
            start = true,
            cheatType = "changedata",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            protectedDatas = { -- ElementDatas Protegidas e os resources que podem alterar
                ['ID'] = {
                    ['idsystem'] = true
                }
            }
        },
        ["Disconnected"] = {
            start = true,
            cheatType = "disconnected",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Trigger Attack"] = {
            start = true,
            cheatType = "attack",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Jetpack"] = {
            start = true,
            cheatType = "jetpack",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ['Fire'] = {
            start = true
        },
        ['Explosions'] = {
            start = true,
            cheatType = "explosions",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            explosionsBlocked = { -- Explosões bloqueadas
                [0] = true,
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                [8] = true,
                [9] = true,
                [10] = true,
                [11] = true,
                [12] = true
            }
        },
        ['Menu'] = {
            start = false,
            cheatType = "menu",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ['Unserialize'] = {
            start = true,
            cheatType = "unserialize",
            punishment = "Kick",
            bypass = {datas = {}, groups = {}}
        },
        ['Lua Executor'] = {
            start = true,
            cheatType = "executor",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            commandsExists = {
                ["commandsExists"] = true
            }
        },
        ['Fake Hardware'] = {
            start = true,
            cheatType = "hardware",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Aimbot"] = {
            start = true,
            cheatType = "aimbot",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Silent Aim"] = {
            start = true,
            cheatType = "silent",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Locked Weapons"] = {
            start = true,
            cheatType = "weaponsbloqued",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            weaponsBloqueds = {
                [16] = true,
                [17] = true,
                [18] = true,
                [35] = true,
                [36] = true,
                [37] = true,
                [38] = true,
                [39] = true,
                [40] = true
            }
        },
        ["Fake Weapons"] = {
            start = true,
            cheatType = "fakeweapon",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
        },
        ["Infinite Ammo"] = {
            start = true,
            cheatType = "infiniteAmmo",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ["Rapid Fire"] = {
            start = true,
            cheatType = "rapidFire",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            shotVelocity = {
                [30] = 0.08, -- Ak 47
                [29] = 0.06, -- Mp5
                [32] = 0.03 -- Tec-9
            }
        },
        ['Air Brake'] = {
            start = true,
            cheatType = "noClip",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ['Teleport'] = {
            start = true,
            cheatType = "teleport",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ['Speed'] = {
            start = true,
            cheatType = "speed",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            defaultGameSpeed = 1
        },
        ['God Mode'] = {
            start = true,
            cheatType = "godmode",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}
        },
        ['Knockback'] = {
            start = true
        },
        ['Pull Player'] = {
            start = true,
            bypass = {datas = {}, groups = {}}
        },
        ['ESP'] = {
            start = true
        },
        ['Pull Vehicle'] = {
            start = true,
            bypass = {datas = {}, groups = {}}
        },
        ['Vehicle Block'] = {
            start = true,
            cheatType = "vehblock",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}}, -- Esse módulo possui um punishment chamado "block", que vai apenas deletar o veículo
            vehicleBlockeds = {
            }
        },
        ['Vehicle Fix'] = {
            start = true,
            cheatType = "vehfix",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            minHealth = 350
        },
        ['Vehicle GodMode'] = {
            start = true,
            cheatType = "vehgodmode",
            punishment = "Warning",
            bypass = {datas = {}, groups = {}},
            minHealth = 350
        }
    },

    ['permissions'] = { -- Logs
        ['Warning'] = {'Everyone', 'Console'},
        ['Ban'] = {'Everyone', 'Console'},
        ['Kick'] = {'Everyone', 'Console'},
        ['Commands'] = {'Everyone', 'Console'}
    },

    ['others'] = {
        ['infobox'] = function(side, player, msg, type)
            if side == 'server' then
                iprint(player, msg)
            elseif side == 'client' then
                iprint(player, msg)
            end
        end,

        ['warning'] = function(message, action)
            if message and action then
                for i, player in ipairs(getElementsByType('player')) do
                    for _, group in ipairs(config.permissions[action]) do
                        if aclGetGroup(group) then
                            if isObjectInACLGroup('user.' ..getAccountName(getPlayerAccount(player)), aclGetGroup(group)) then
                                outputChatBox(" ", player, 255, 255, 255, true)
                                outputChatBox("#7F8AF4[NXAC] " .. message, player, 255, 255, 255, true)
                                outputChatBox(" ", player, 255, 255, 255, true)
                                break
                            end
                        end
                    end
                end
            end
        end,

        ----------------------
        ----------------------
        -- Player Functions --
        ----------------------
        ----------------------

        ['getPlayerName'] = function(player)
            return string.gsub(getPlayerName(player), "#%x%x%x%x%x%x", "")
        end,
        ['getPlayerIdentification'] = function(player)
            return (getElementData(player, "ID") or 'n/a')
        end,
        ['getPlayerByIdentification'] = function(identificator)
            for _, p in ipairs(getElementsByType("player")) do
                if (getElementData(p, "ID") == tonumber(identificator)) then
                    return p
                end
            end
            return false
        end
    }
}

discordWebhooks = {
    ['Warning'] = {url = ''},
    ['Kick'] = {url = ''},
    ['InstaKick'] = {url = ''},
    ['Ban'] = {url = ''},
    ['Commands'] = {url = ''},
    ['Screenshot'] = {url = ''}
}
